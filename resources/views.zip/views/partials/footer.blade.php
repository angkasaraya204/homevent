<div class="position-relative overflow-hidden text-center bg-dark text-light">
    <div class="col-md-8 p-lg-3 mx-auto my-5">
        <h1 class="display-6 fw-normal">Testimoni</p>
        <p class="lead fw-normal">"Pengalaman yang tak terlupakan sih, mulai dari band sampai event beragam banget."</p>
        <p class="lead fw-normal">Fadri, Jakarta</p>
    </div>
</div>