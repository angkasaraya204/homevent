<div class="footer-left">
    Copyright &copy; 2018
</div>
<div class="footer-right">

</div>